# Databricks notebook source
from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS Silver;
# MAGIC CREATE DATABASE IF NOT EXISTS Gold;

# COMMAND ----------

df_silver = spark.read.format("delta").table("Bronze.vendas")

# COMMAND ----------

display(df_silver)

# COMMAND ----------

df_silver.printSchema()

# COMMAND ----------

for column in df_silver.columns:
    df_temp = df_silver.filter(df_silver[column].isNull())
    print(f"Valores nulos na coluna: {column}")
    display(df_temp)


# COMMAND ----------

df_silver.dropna(how = "all")

# COMMAND ----------

df_silver.dropDuplicates()

# COMMAND ----------

order_window = Window.orderBy("Ano_venda", "Mês_venda")

# COMMAND ----------

df_sales = df_silver.groupBy("Ano_venda", "Mês_venda").agg(round(sum("val_venda")).alias("total_venda"))

# COMMAND ----------

df_last_sales = df_sales.withColumn("last_sales", lag("total_venda").over(order_window))

# COMMAND ----------

sales_month = df_sales.withColumn("vendas_mes_anterior", lag("total_venda").over(order_window))

# COMMAND ----------

df_month_growth = df_last_sales.withColumn(
    "crescimento_mensal",
    when(
        col("last_sales").isNotNull(),
        round(((col("total_venda") - col("last_sales")) / col("last_sales")) * 100, 2)
    ).otherwise(0)
)

# COMMAND ----------

display(df_month_growth)

# COMMAND ----------

df_month_growth.write.mode("overwrite").format("delta").saveAsTable("Silver.vendas_cresc_mensal")

# COMMAND ----------

dim_cliente = df_silver.select("cod_cliente", "nom_cliente").distinct()


# COMMAND ----------

dim_vendedor = df_silver.select("cod_vendedor", "nom_vendedor").distinct()


# COMMAND ----------

dim_cidade = df_silver.select("cod_cidade", "nom_cidade", "Latitude", "Longitude").distinct()


# COMMAND ----------

dim_produto = df_silver.select("cod_produto", "Nom_produto", "cod_marca", "cod_departamento", "cod_gerencia").distinct()


# COMMAND ----------

dim_marca = df_silver.select("cod_marca", "Nom_marca").distinct()


# COMMAND ----------

dim_departamento = df_silver.select("cod_departamento", "nom_departamento", "cod_gerencia").distinct()


# COMMAND ----------

dim_gerencia = df_silver.select("cod_gerencia", "nom_gerencia").distinct()

# COMMAND ----------

fato_vendas = df_silver.select(
    "id_venda",
    "dtc_venda",
    "Ano_venda",
    "Mês_venda",
    "Dia_venda",
    "qtd_venda",
    "val_venda",
    "num_nota",
    "cod_cliente",
    "cod_vendedor",
    "cod_produto",
    "cod_marca",
    "cod_departamento",
    "cod_gerencia",
    "cod_cidade"
)


# COMMAND ----------

fato_vendas.write.mode("overwrite").format("delta").saveAsTable("Gold.fato_vendas")
dim_cliente.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_cliente")
dim_vendedor.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_vendedor")
dim_cidade.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_cidade")
dim_produto.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_produto")
dim_marca.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_marca")
dim_departamento.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_departamento")
dim_gerencia.write.mode("overwrite").format("delta").saveAsTable("Gold.dim_gerencia")
