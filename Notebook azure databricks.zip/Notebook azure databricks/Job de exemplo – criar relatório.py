# Databricks notebook source
df_gold = spark.read.format("delta").table("Gold.fato_vendas")

# COMMAND ----------

display(df_gold)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT nom_departamento, nom_gerencia FROM Gold.dim_departamento JOIN Gold.dim_gerencia ON Gold.dim_departamento.cod_gerencia = Gold.dim_gerencia.cod_gerencia