# Databricks notebook source
from pyspark.sql import *

# COMMAND ----------

display(dbutils.fs.ls("FileStore/tables"))

# COMMAND ----------

df = spark.read.csv("dbfs:/FileStore/tables/vendas.csv", header=True, inferSchema=True, encoding="ISO-8859-1")
display(df)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS Bronze;

# COMMAND ----------

# MAGIC %sql
# MAGIC USE DATABASE Bronze;

# COMMAND ----------

df.write.mode("overwrite").saveAsTable("Bronze.vendas")